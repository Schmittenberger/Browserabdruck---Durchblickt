const Config = {
	//possible configuration for future expansion
}

// POPUP Configuration
const PopupConfig = {
	//possible configuration for future expansion

}